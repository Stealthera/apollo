"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Heart, Shield, Clock, Users, ArrowRight, CheckCircle2 } from "lucide-react"

import { Button } from "@/components/ui/button"

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

export default function AboutPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="container relative z-10">
          <motion.div
            className="flex flex-col items-center text-center max-w-3xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
              Our <span className="gradient-text">Mission</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-6 max-w-2xl">
              We're on a mission to revolutionize elder care through compassionate technology.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-20 md:py-28">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeIn}>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">The Problem We Solve</h2>
              <p className="text-muted-foreground text-lg mb-6">
                We founded ElderCareAI after experiencing firsthand the challenges of caring for aging loved ones. The
                elder care industry faces critical pain points that technology can address:
              </p>
              <ul className="space-y-4">
                <li className="flex items-start">
                  <CheckCircle2 className="h-6 w-6 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="font-medium">Caregiver burnout</span> - The emotional and physical toll on family
                    members and professional caregivers
                  </span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="h-6 w-6 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="font-medium">Delayed emergency response</span> - Critical minutes lost when health
                    incidents occur
                  </span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="h-6 w-6 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="font-medium">Fragmented data</span> - Lack of comprehensive health insights across
                    different care systems
                  </span>
                </li>
                <li className="flex items-start">
                  <CheckCircle2 className="h-6 w-6 text-primary mr-2 mt-0.5 flex-shrink-0" />
                  <span>
                    <span className="font-medium">Isolation and loneliness</span> - The emotional impact of reduced
                    human interaction
                  </span>
                </li>
              </ul>
            </motion.div>
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
              className="relative"
            >
              <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-primary/20 to-secondary/20 blur-xl opacity-70"></div>
              <div className="relative rounded-xl overflow-hidden">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  width={800}
                  height={600}
                  alt="Elderly person with caregiver"
                  className="w-full h-auto"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Our Values Section */}
      <section className="py-20 md:py-28 bg-card">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Core Values</h2>
            <p className="text-muted-foreground text-lg">The principles that guide everything we do at ElderCareAI.</p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Heart className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Compassion</h3>
              <p className="text-muted-foreground">
                We approach every decision with empathy for seniors and their families.
              </p>
            </motion.div>

            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Dignity</h3>
              <p className="text-muted-foreground">
                We design solutions that respect privacy and promote independence.
              </p>
            </motion.div>

            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Innovation</h3>
              <p className="text-muted-foreground">We continuously improve our technology to provide better care.</p>
            </motion.div>

            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Accessibility</h3>
              <p className="text-muted-foreground">We make advanced care solutions available to all who need them.</p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 md:py-28">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose Us</h2>
            <p className="text-muted-foreground text-lg">
              Our unique advantages set us apart in the elder care technology space.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            <motion.div
              className="bg-card rounded-xl p-6 border"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
            >
              <h3 className="text-xl font-medium mb-4">Advanced Predictive Analytics</h3>
              <p className="text-muted-foreground mb-4">
                Our AI doesn't just monitor—it predicts potential health issues before they become emergencies, giving
                caregivers precious time to intervene.
              </p>
              <div className="h-px w-full bg-gradient-to-r from-primary/50 to-secondary/50 my-4"></div>
              <p className="text-sm text-muted-foreground italic">
                "The predictive alerts have given us time to address issues before they become critical."
              </p>
            </motion.div>

            <motion.div
              className="bg-card rounded-xl p-6 border"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.3 }}
              variants={fadeIn}
            >
              <h3 className="text-xl font-medium mb-4">Intuitive User Experience</h3>
              <p className="text-muted-foreground mb-4">
                Designed with input from caregivers and seniors, our platform is exceptionally easy to use, requiring
                minimal technical knowledge.
              </p>
              <div className="h-px w-full bg-gradient-to-r from-primary/50 to-secondary/50 my-4"></div>
              <p className="text-sm text-muted-foreground italic">
                "Even our most tech-resistant staff members picked it up within minutes."
              </p>
            </motion.div>

            <motion.div
              className="bg-card rounded-xl p-6 border"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, amount: 0.3 }}
              variants={fadeIn}
            >
              <h3 className="text-xl font-medium mb-4">Privacy and Compliance Focus</h3>
              <p className="text-muted-foreground mb-4">
                Built from the ground up with HIPAA compliance and data security as core principles, not afterthoughts.
              </p>
              <div className="h-px w-full bg-gradient-to-r from-primary/50 to-secondary/50 my-4"></div>
              <p className="text-sm text-muted-foreground italic">
                "The robust privacy features gave us confidence to implement the system facility-wide."
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 md:py-28 bg-card">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Team</h2>
            <p className="text-muted-foreground text-lg">Meet the experts behind our technology.</p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            {[
              {
                name: "Dr. Sarah Chen",
                role: "Chief Medical Officer",
                bio: "Former geriatric physician with 15+ years of experience in elder care and healthcare technology.",
              },
              {
                name: "Michael Rodriguez",
                role: "Chief Technology Officer",
                bio: "AI specialist with background in developing healthcare algorithms and predictive models.",
              },
              {
                name: "Aisha Johnson",
                role: "Head of User Experience",
                bio: "Dedicated to creating accessible, intuitive interfaces for users of all technical abilities.",
              },
            ].map((member, index) => (
              <motion.div key={index} className="bg-background rounded-xl p-6 border text-center" variants={fadeIn}>
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 mx-auto mb-4 overflow-hidden">
                  <Image
                    src={`/placeholder.svg?height=200&width=200`}
                    width={200}
                    height={200}
                    alt={member.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-medium mb-1">{member.name}</h3>
                <p className="text-primary text-sm mb-3">{member.role}</p>
                <p className="text-muted-foreground text-sm">{member.bio}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-gradient-to-br from-primary/20 via-background to-secondary/20">
        <div className="container">
          <motion.div
            className="max-w-4xl mx-auto text-center"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Join Our Mission</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Help us transform the future of elder care with compassionate technology.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="px-8">
                <Link href="/demo" className="flex items-center">
                  Request a Demo
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="px-8 animated-gradient-border">
                <Link href="/contact">Contact Us</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

