"use client"

import React from "react"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Activity, Brain, Mic, Smartphone, Shield, Bell, Heart, LineChart, Zap, ArrowRight, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

export default function FeaturesPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="container relative z-10">
          <motion.div
            className="flex flex-col items-center text-center max-w-3xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
              Comprehensive <span className="gradient-text">Features</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-6 max-w-2xl">
              Discover how our AI-powered platform transforms elder care with these powerful capabilities.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Features Section */}
      <section className="py-20 md:py-28">
        <div className="container">
          <Tabs defaultValue="dashboard" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full max-w-3xl">
                <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
                <TabsTrigger value="predictive">Predictive AI</TabsTrigger>
                <TabsTrigger value="voice">Voice Assistant</TabsTrigger>
                <TabsTrigger value="emergency">Emergency SOS</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="dashboard" className="mt-0">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeIn}>
                  <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold mb-4 text-primary">
                    <Activity className="mr-1 h-3.5 w-3.5" />
                    Unified Dashboard
                  </div>
                  <h2 className="text-3xl font-bold mb-6">Complete Oversight in One View</h2>
                  <p className="text-muted-foreground text-lg mb-6">
                    Our intuitive dashboard brings together all critical information in a single, easy-to-understand
                    interface.
                  </p>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Activity className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Real-time Vitals Monitoring</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Track heart rate, sleep patterns, activity levels, and more with continuous updates.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <LineChart className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Trend Analysis</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          View historical data to identify patterns and changes over time.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Bell className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Customizable Alerts</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Set personalized thresholds for notifications based on individual needs.
                        </p>
                      </div>
                    </li>
                  </ul>
                </motion.div>
                <motion.div
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeIn}
                  className="relative"
                >
                  <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-primary/20 to-secondary/20 blur-xl opacity-70"></div>
                  <div className="relative rounded-xl overflow-hidden border">
                    <Image
                      src="/placeholder.svg?height=600&width=800"
                      width={800}
                      height={600}
                      alt="Dashboard Interface"
                      className="w-full h-auto"
                    />
                  </div>
                </motion.div>
              </div>
            </TabsContent>

            <TabsContent value="predictive" className="mt-0">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeIn}>
                  <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold mb-4 text-primary">
                    <Brain className="mr-1 h-3.5 w-3.5" />
                    AI Predictive Models
                  </div>
                  <h2 className="text-3xl font-bold mb-6">Anticipate Health Changes</h2>
                  <p className="text-muted-foreground text-lg mb-6">
                    Our advanced AI models analyze patterns to predict potential health issues before they become
                    critical.
                  </p>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Heart className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Cardiac Event Prediction</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Identifies subtle changes in heart rhythm that may indicate upcoming issues.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Brain className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Cognitive Pattern Analysis</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Detects changes in daily routines that might signal cognitive decline.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Activity className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Mobility Decline Detection</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Recognizes gradual changes in movement patterns to prevent falls.
                        </p>
                      </div>
                    </li>
                  </ul>
                </motion.div>
                <motion.div
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeIn}
                  className="relative"
                >
                  <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-primary/20 to-secondary/20 blur-xl opacity-70"></div>
                  <div className="relative rounded-xl overflow-hidden border">
                    <Image
                      src="/placeholder.svg?height=600&width=800"
                      width={800}
                      height={600}
                      alt="Predictive Analytics Interface"
                      className="w-full h-auto"
                    />
                  </div>
                </motion.div>
              </div>
            </TabsContent>

            <TabsContent value="voice" className="mt-0">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeIn}>
                  <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold mb-4 text-primary">
                    <Mic className="mr-1 h-3.5 w-3.5" />
                    Emotion-Aware Voice Assistant
                  </div>
                  <h2 className="text-3xl font-bold mb-6">Natural Conversation Interface</h2>
                  <p className="text-muted-foreground text-lg mb-6">
                    Our voice assistant understands not just words, but emotional cues to provide truly responsive care.
                  </p>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Mic className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Natural Language Processing</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Understands conversational speech, even with varied accents and speech patterns.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Heart className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Emotional Intelligence</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Detects stress, anxiety, or distress in voice patterns and responds appropriately.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Bell className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Voice-Activated Assistance</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Enables hands-free control of smart home features and emergency calls.
                        </p>
                      </div>
                    </li>
                  </ul>
                </motion.div>
                <motion.div
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeIn}
                  className="relative"
                >
                  <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-primary/20 to-secondary/20 blur-xl opacity-70"></div>
                  <div className="relative rounded-xl overflow-hidden border">
                    <Image
                      src="/placeholder.svg?height=600&width=800"
                      width={800}
                      height={600}
                      alt="Voice Assistant Interface"
                      className="w-full h-auto"
                    />
                  </div>
                </motion.div>
              </div>
            </TabsContent>

            <TabsContent value="emergency" className="mt-0">
              <div className="grid lg:grid-cols-2 gap-12 items-center">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeIn}>
                  <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold mb-4 text-primary">
                    <Zap className="mr-1 h-3.5 w-3.5" />
                    Emergency SOS & Quick Response
                  </div>
                  <h2 className="text-3xl font-bold mb-6">Immediate Help When Needed</h2>
                  <p className="text-muted-foreground text-lg mb-6">
                    Our emergency system ensures rapid response in critical situations, potentially saving lives.
                  </p>
                  <ul className="space-y-4">
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Bell className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Automatic Fall Detection</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Identifies falls and immediately alerts caregivers and emergency contacts.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Zap className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">One-Touch SOS</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Simple button press or voice command activates emergency protocols.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start">
                      <div className="rounded-full bg-primary/10 p-1 mr-3 mt-0.5">
                        <Shield className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <span className="font-medium">Escalation Protocols</span>
                        <p className="text-sm text-muted-foreground mt-1">
                          Tiered response system ensures appropriate help based on the situation's severity.
                        </p>
                      </div>
                    </li>
                  </ul>
                </motion.div>
                <motion.div
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeIn}
                  className="relative"
                >
                  <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-primary/20 to-secondary/20 blur-xl opacity-70"></div>
                  <div className="relative rounded-xl overflow-hidden border">
                    <Image
                      src="/placeholder.svg?height=600&width=800"
                      width={800}
                      height={600}
                      alt="Emergency Response Interface"
                      className="w-full h-auto"
                    />
                  </div>
                </motion.div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Additional Features Grid */}
      <section className="py-20 md:py-28 bg-card">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">More Powerful Features</h2>
            <p className="text-muted-foreground text-lg">
              Our platform offers a comprehensive suite of tools designed specifically for elder care.
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            {[
              {
                icon: <Shield />,
                title: "HIPAA Compliant",
                description: "Built from the ground up with privacy and security in mind.",
              },
              {
                icon: <Smartphone />,
                title: "Mobile Companion App",
                description: "Stay connected with loved ones from anywhere with our mobile app.",
              },
              {
                icon: <Activity />,
                title: "Medication Reminders",
                description: "Smart scheduling and verification of medication adherence.",
              },
              {
                icon: <Users />,
                title: "Multi-Caregiver Support",
                description: "Coordinate care across family members and professional caregivers.",
              },
              {
                icon: <LineChart />,
                title: "Health Reports",
                description: "Generate comprehensive reports for healthcare providers.",
              },
              {
                icon: <Bell />,
                title: "Custom Notifications",
                description: "Tailor alerts based on individual needs and preferences.",
              },
            ].map((feature, index) => (
              <motion.div key={index} className="feature-card" variants={fadeIn}>
                <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                  {React.cloneElement(feature.icon, { className: "h-6 w-6 text-primary" })}
                </div>
                <h3 className="text-xl font-medium mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-gradient-to-br from-primary/20 via-background to-secondary/20">
        <div className="container">
          <motion.div
            className="max-w-4xl mx-auto text-center"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Experience These Features?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              See how our platform can transform your elder care approach.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="px-8">
                <Link href="/demo" className="flex items-center">
                  Request a Demo
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="px-8 animated-gradient-border">
                <Link href="/pricing">View Pricing</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

