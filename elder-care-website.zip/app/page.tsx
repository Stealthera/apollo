"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Activity, Brain, Mic, Smartphone, ChevronRight, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

export default function Home() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 lg:py-36 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="container relative z-10">
          <motion.div
            className="flex flex-col items-center text-center max-w-4xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Empowering Elder Care <span className="gradient-text">with AI.</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl">
              Real-time monitoring, predictive health insights, and empathetic interactions—all in one platform.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="px-8">
                <Link href="/demo">Request a Demo</Link>
              </Button>
              <Button size="lg" variant="outline" className="px-8 animated-gradient-border">
                <Link href="/pricing">Start Your Free Trial</Link>
              </Button>
            </div>
          </motion.div>

          <motion.div
            className="mt-16 md:mt-20"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="relative mx-auto max-w-5xl">
              <div className="absolute -inset-1 rounded-xl bg-gradient-to-r from-primary/30 to-secondary/30 blur-xl opacity-70"></div>
              <div className="relative rounded-xl border bg-card/50 backdrop-blur-sm overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=600&width=1200"
                  width={1200}
                  height={600}
                  alt="ElderCare AI Dashboard"
                  className="w-full h-auto"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 md:py-28">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Comprehensive Care Features</h2>
            <p className="text-muted-foreground text-lg">
              Our platform combines cutting-edge AI technology with intuitive design to provide a complete elder care
              solution.
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Activity className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Real-time Health Monitoring</h3>
              <p className="text-muted-foreground">
                Continuous tracking of vital signs and activity patterns to ensure wellbeing.
              </p>
            </motion.div>

            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Brain className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Predictive Health Analytics</h3>
              <p className="text-muted-foreground">
                AI-powered insights to anticipate health issues before they become critical.
              </p>
            </motion.div>

            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Mic className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Emotion-driven Voice Assistant</h3>
              <p className="text-muted-foreground">
                Natural conversation interface that responds to emotional cues and needs.
              </p>
            </motion.div>

            <motion.div className="feature-card" variants={fadeIn}>
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mb-4">
                <Smartphone className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-medium mb-2">Seamless Device Integration</h3>
              <p className="text-muted-foreground">Works with existing smart home devices and healthcare systems.</p>
            </motion.div>
          </motion.div>

          <div className="mt-12 text-center">
            <Button variant="outline" className="group">
              <Link href="/features" className="flex items-center">
                Explore All Features
                <ChevronRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Impact Numbers */}
      <section className="py-20 md:py-28 bg-card">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Measurable Impact</h2>
            <p className="text-muted-foreground text-lg">
              Our platform delivers real results for caregivers and their loved ones.
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.div className="text-center p-6 rounded-xl bg-card border" variants={fadeIn}>
              <div className="text-4xl md:text-5xl font-bold mb-2 gradient-text">40%</div>
              <p className="text-muted-foreground">Increase in caregiver efficiency</p>
            </motion.div>

            <motion.div className="text-center p-6 rounded-xl bg-card border" variants={fadeIn}>
              <div className="text-4xl md:text-5xl font-bold mb-2 gradient-text">62%</div>
              <p className="text-muted-foreground">Reduction in emergency incidents</p>
            </motion.div>

            <motion.div className="text-center p-6 rounded-xl bg-card border" variants={fadeIn}>
              <div className="text-4xl md:text-5xl font-bold mb-2 gradient-text">85%</div>
              <p className="text-muted-foreground">Of users report improved peace of mind</p>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 md:py-28">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-muted-foreground text-lg">
              Testimonials from our early adopters will be featured here once available.
            </p>
          </motion.div>

          <motion.div
            className="max-w-4xl mx-auto"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <Card className="border-dashed">
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground mb-6">
                  We're currently collecting feedback from our pilot program participants. Check back soon to see what
                  healthcare professionals and families are saying about ElderCareAI.
                </p>
                <Button variant="outline">
                  <Link href="/contact">Join Our Pilot Program</Link>
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-gradient-to-br from-primary/20 via-background to-secondary/20">
        <div className="container">
          <motion.div
            className="max-w-4xl mx-auto text-center"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Transform Elder Care?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join the revolution in compassionate, AI-powered care solutions.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="px-8">
                <Link href="/demo" className="flex items-center">
                  Request a Demo
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="px-8 animated-gradient-border">
                <Link href="/pricing">Start Your Free Trial</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

