"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { CheckCircle2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

export default function DemoPage() {
  const [mounted, setMounted] = useState(false)
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    facilityName: "",
    email: "",
    phone: "",
    organizationType: "",
    message: "",
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRadioChange = (value) => {
    setFormData((prev) => ({ ...prev, organizationType: value }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Here you would normally send the data to your backend
    console.log("Form submitted:", formData)
    setFormSubmitted(true)
  }

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="container relative z-10">
          <motion.div
            className="flex flex-col items-center text-center max-w-3xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
              Request a <span className="gradient-text">Demo</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-6 max-w-2xl">
              See how ElderCareAI can transform your approach to elder care with a personalized demonstration.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Form Section */}
      <section className="py-12 md:py-20">
        <div className="container max-w-4xl">
          {!formSubmitted ? (
            <motion.div initial="hidden" animate="visible" variants={fadeIn}>
              <Card>
                <CardContent className="p-6 md:p-10">
                  <form onSubmit={handleSubmit} className="space-y-8">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="name">Your Name</Label>
                        <Input
                          id="name"
                          name="name"
                          placeholder="John Doe"
                          required
                          value={formData.name}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="facilityName">Facility/Organization Name</Label>
                        <Input
                          id="facilityName"
                          name="facilityName"
                          placeholder="Acme Care Center"
                          value={formData.facilityName}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="john@example.com"
                          required
                          value={formData.email}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input
                          id="phone"
                          name="phone"
                          placeholder="(555) 123-4567"
                          value={formData.phone}
                          onChange={handleChange}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Organization Type</Label>
                      <RadioGroup
                        value={formData.organizationType}
                        onValueChange={handleRadioChange}
                        className="grid grid-cols-2 md:grid-cols-4 gap-4"
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="individual" id="individual" />
                          <Label htmlFor="individual">Individual/Family</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="care-home" id="care-home" />
                          <Label htmlFor="care-home">Care Home</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="healthcare" id="healthcare" />
                          <Label htmlFor="healthcare">Healthcare Facility</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="other" id="other" />
                          <Label htmlFor="other">Other</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="message">How can we help you?</Label>
                      <Textarea
                        id="message"
                        name="message"
                        placeholder="Tell us about your specific needs or questions..."
                        rows={5}
                        value={formData.message}
                        onChange={handleChange}
                      />
                    </div>

                    <Button type="submit" className="w-full md:w-auto">
                      Request Demo
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div initial="hidden" animate="visible" variants={fadeIn} className="text-center">
              <Card>
                <CardContent className="p-10 flex flex-col items-center">
                  <div className="rounded-full bg-primary/10 p-3 w-16 h-16 flex items-center justify-center mb-6">
                    <CheckCircle2 className="h-8 w-8 text-primary" />
                  </div>
                  <h2 className="text-2xl font-bold mb-2">Thank You!</h2>
                  <p className="text-muted-foreground mb-6 max-w-md">
                    Your demo request has been received. One of our representatives will contact you within 24 hours to
                    schedule your personalized demonstration.
                  </p>
                  <Button variant="outline" onClick={() => setFormSubmitted(false)}>
                    Submit Another Request
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </div>
      </section>

      {/* What to Expect Section */}
      <section className="py-20 md:py-28 bg-card">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What to Expect</h2>
            <p className="text-muted-foreground text-lg">
              Our demo process is designed to give you a comprehensive understanding of our platform.
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <div className="bg-background rounded-xl p-6 border text-center">
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-primary">1</span>
              </div>
              <h3 className="text-xl font-medium mb-2">Initial Consultation</h3>
              <p className="text-muted-foreground">
                We'll discuss your specific needs and challenges to customize the demonstration.
              </p>
            </div>
            <div className="bg-background rounded-xl p-6 border text-center">
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-primary">2</span>
              </div>
              <h3 className="text-xl font-medium mb-2">Live Demonstration</h3>
              <p className="text-muted-foreground">
                See the platform in action with real-world scenarios relevant to your situation.
              </p>
            </div>
            <div className="bg-background rounded-xl p-6 border text-center">
              <div className="rounded-full bg-primary/10 p-3 w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <span className="text-xl font-bold text-primary">3</span>
              </div>
              <h3 className="text-xl font-medium mb-2">Q&A and Follow-up</h3>
              <p className="text-muted-foreground">
                Get answers to your questions and discuss next steps for implementation.
              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 md:py-28">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Others Are Saying</h2>
            <p className="text-muted-foreground text-lg">Hear from organizations that have implemented ElderCareAI.</p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <div className="bg-card rounded-xl p-6 border">
              <p className="italic mb-4">
                "The demo was incredibly helpful in showing us exactly how the platform could address our specific
                challenges. Implementation was smooth, and we've seen remarkable improvements in our care efficiency."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-primary/20 mr-3"></div>
                <div>
                  <p className="font-medium">Sarah Johnson</p>
                  <p className="text-sm text-muted-foreground">Director of Care, Sunshine Assisted Living</p>
                </div>
              </div>
            </div>
            <div className="bg-card rounded-xl p-6 border">
              <p className="italic mb-4">
                "As a family caregiver, I was skeptical about technology solutions, but the demo showed me how intuitive
                the system is. It's given our family peace of mind and helped us provide better care for my father."
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-primary/20 mr-3"></div>
                <div>
                  <p className="font-medium">Michael Rodriguez</p>
                  <p className="text-sm text-muted-foreground">Family Caregiver</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 md:py-28 bg-card">
        <div className="container max-w-4xl">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-muted-foreground text-lg">Common questions about our demo process.</p>
          </motion.div>

          <motion.div
            className="space-y-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <div className="bg-background rounded-xl p-6 border">
              <h3 className="text-lg font-medium mb-2">How long does the demo typically last?</h3>
              <p className="text-muted-foreground">
                Our demos usually last 30-45 minutes, including time for questions and discussion.
              </p>
            </div>
            <div className="bg-background rounded-xl p-6 border">
              <h3 className="text-lg font-medium mb-2">Do I need any technical knowledge to understand the demo?</h3>
              <p className="text-muted-foreground">
                Not at all. Our demos are designed to be accessible to everyone, regardless of technical background.
              </p>
            </div>
            <div className="bg-background rounded-xl p-6 border">
              <h3 className="text-lg font-medium mb-2">Can I invite multiple team members to the demo?</h3>
              <p className="text-muted-foreground">
                We encourage you to include all stakeholders who would be involved in the decision-making process.
              </p>
            </div>
            <div className="bg-background rounded-xl p-6 border">
              <h3 className="text-lg font-medium mb-2">Is there any obligation after the demo?</h3>
              <p className="text-muted-foreground">
                No, the demo is completely free and comes with no obligations. It's simply an opportunity for you to see
                if our solution meets your needs.
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

