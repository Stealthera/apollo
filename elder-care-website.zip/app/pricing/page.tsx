"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Check, ArrowRight, HelpCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

const fadeIn = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6 },
  },
}

const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
    },
  },
}

const pricingPlans = [
  {
    name: "Basic",
    description: "Essential monitoring for individuals",
    price: "$49",
    features: [
      "Real-time Health Monitoring",
      "Basic Alert System",
      "Mobile App Access",
      "Email Support",
      "1 Caregiver Account",
    ],
    limitations: ["No Predictive Analytics", "No Voice Assistant", "Limited Reporting"],
  },
  {
    name: "Standard",
    description: "Complete solution for families",
    price: "$99",
    popular: true,
    features: [
      "Everything in Basic",
      "Voice Assistant Integration",
      "Basic Predictive Analytics",
      "Medication Management",
      "3 Caregiver Accounts",
      "Priority Email Support",
      "Phone Support",
    ],
    limitations: ["Limited AI Models", "Basic Reporting Only"],
  },
  {
    name: "Premium",
    description: "Advanced care for healthcare facilities",
    price: "$199",
    features: [
      "Everything in Standard",
      "Full AI Predictive Suite",
      "Advanced Voice Assistant",
      "Unlimited Caregiver Accounts",
      "Custom Integration Options",
      "Comprehensive Reporting",
      "24/7 Priority Support",
      "Dedicated Account Manager",
    ],
    limitations: [],
  },
]

export default function PricingPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative py-20 md:py-28 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
        <div className="container relative z-10">
          <motion.div
            className="flex flex-col items-center text-center max-w-3xl mx-auto"
            initial="hidden"
            animate="visible"
            variants={fadeIn}
          >
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-6">
              Simple, Transparent <span className="gradient-text">Pricing</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-6 max-w-2xl">
              Choose the plan that fits your needs. All plans include a 14-day free trial.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="py-12 md:py-20">
        <div className="container">
          <motion.div
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            {pricingPlans.map((plan, index) => (
              <motion.div key={index} variants={fadeIn}>
                <Card className={`h-full flex flex-col ${plan.popular ? "border-primary" : ""}`}>
                  {plan.popular && (
                    <div className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/2">
                      Most Popular
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle className="text-2xl">{plan.name}</CardTitle>
                    <CardDescription>{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <div className="mb-6">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-muted-foreground ml-2">/ month</span>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-medium">Includes:</h4>
                      <ul className="space-y-2">
                        {plan.features.map((feature, i) => (
                          <li key={i} className="flex items-start">
                            <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>

                      {plan.limitations.length > 0 && (
                        <>
                          <h4 className="font-medium mt-6">Limitations:</h4>
                          <ul className="space-y-2">
                            {plan.limitations.map((limitation, i) => (
                              <li key={i} className="flex items-start text-muted-foreground">
                                <span className="mr-2">•</span>
                                <span>{limitation}</span>
                              </li>
                            ))}
                          </ul>
                        </>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className={`w-full ${plan.popular ? "" : "variant-outline"}`}
                      variant={plan.popular ? "default" : "outline"}
                    >
                      <Link href="/demo" className="flex items-center justify-center w-full">
                        Get Started
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 md:py-28 bg-card">
        <div className="container">
          <motion.div
            className="text-center max-w-3xl mx-auto mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-muted-foreground text-lg">
              Find answers to common questions about our pricing and features.
            </p>
          </motion.div>

          <motion.div
            className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            {[
              {
                question: "Can I switch plans later?",
                answer:
                  "Yes, you can upgrade or downgrade your plan at any time. Changes take effect at the start of your next billing cycle.",
              },
              {
                question: "Is there a setup fee?",
                answer:
                  "No, there are no hidden fees. The price you see is the price you pay, with no additional setup costs.",
              },
              {
                question: "Do you offer discounts for healthcare facilities?",
                answer:
                  "Yes, we offer volume discounts for healthcare facilities. Contact our sales team for custom pricing.",
              },
              {
                question: "What payment methods do you accept?",
                answer: "We accept all major credit cards, ACH transfers, and invoicing for enterprise customers.",
              },
              {
                question: "Is my data secure?",
                answer:
                  "Absolutely. We're HIPAA compliant and use enterprise-grade encryption to protect all your data.",
              },
              {
                question: "Can I cancel anytime?",
                answer: "Yes, you can cancel your subscription at any time with no cancellation fees.",
              },
            ].map((faq, index) => (
              <motion.div key={index} className="bg-background rounded-xl p-6 border" variants={fadeIn}>
                <h3 className="text-lg font-medium mb-2 flex items-center">
                  {faq.question}
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <HelpCircle className="h-4 w-4 ml-2 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p className="max-w-xs">{faq.answer}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </h3>
                <p className="text-muted-foreground">{faq.answer}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Enterprise Section */}
      <section className="py-20 md:py-28">
        <div className="container">
          <div className="bg-card border rounded-xl p-8 md:p-12 max-w-5xl mx-auto">
            <motion.div
              className="grid md:grid-cols-2 gap-8 items-center"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeIn}
            >
              <div>
                <h2 className="text-3xl font-bold mb-4">Need a Custom Solution?</h2>
                <p className="text-muted-foreground mb-6">
                  For healthcare facilities, nursing homes, and large-scale deployments, we offer tailored enterprise
                  solutions.
                </p>
                <ul className="space-y-2 mb-6">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                    <span>Custom integration with existing systems</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                    <span>Volume discounts for multiple users</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                    <span>Dedicated account management</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                    <span>Custom training and onboarding</span>
                  </li>
                </ul>
                <Button>
                  <Link href="/contact" className="flex items-center">
                    Contact Sales
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-xl p-8 text-center">
                <h3 className="text-xl font-medium mb-4">Enterprise Benefits</h3>
                <div className="space-y-4">
                  <div className="bg-background/50 backdrop-blur-sm rounded-lg p-4">
                    <p className="font-medium">Flexible Deployment Options</p>
                    <p className="text-sm text-muted-foreground">On-premises or cloud-based solutions</p>
                  </div>
                  <div className="bg-background/50 backdrop-blur-sm rounded-lg p-4">
                    <p className="font-medium">Advanced Analytics</p>
                    <p className="text-sm text-muted-foreground">Facility-wide insights and reporting</p>
                  </div>
                  <div className="bg-background/50 backdrop-blur-sm rounded-lg p-4">
                    <p className="font-medium">Priority Support</p>
                    <p className="text-sm text-muted-foreground">24/7 dedicated technical assistance</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-28 bg-gradient-to-br from-primary/20 via-background to-secondary/20">
        <div className="container">
          <motion.div
            className="max-w-4xl mx-auto text-center"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeIn}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Start Your Free Trial Today</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Experience the full power of ElderCareAI with no commitment for 14 days.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="px-8">
                <Link href="/demo" className="flex items-center">
                  Get Started
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="px-8 animated-gradient-border">
                <Link href="/contact">Contact Sales</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

